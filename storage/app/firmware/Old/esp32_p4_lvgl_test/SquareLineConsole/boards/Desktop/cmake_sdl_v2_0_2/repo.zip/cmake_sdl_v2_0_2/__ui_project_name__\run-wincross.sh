wine  build/__UI_PROJECT_NAME__.exe
